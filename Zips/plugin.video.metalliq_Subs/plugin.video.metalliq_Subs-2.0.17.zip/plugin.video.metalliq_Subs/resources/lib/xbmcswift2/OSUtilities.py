# -*- coding: utf-8 -*- 

import os
import sys
import xbmc
import struct
import urllib
import xbmcvfs
import xmlrpclib,urllib2
from xbmcswift2.logger import log
import xbmcaddon
import unicodedata,logging
from xbmcaddon import Addon
import StorageServer
__addon__      = xbmcaddon.Addon()
__version__    = __addon__.getAddonInfo('version') # Module version
__scriptname__ = "XBMC Subtitles Unofficial"
store = StorageServer.StorageServer(__scriptname__, 1)  # 6 months
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
BASE_URL_XMLRPC = u"http://api.opensubtitles.org/xml-rpc"
MyAddon = Addon()
class OSDBServer:
  def __init__( self, *args, **kwargs ):

    self.server = xmlrpclib.Server( BASE_URL_XMLRPC, verbose=0 )

    self.osdb_token  =self.get_user_token ()
    

  def get_user_token(self):

        results = store.get('credentials')
        if results:
            results = (results)
        else:
            results = self.server.LogIn("", "", "en", "%s_v%s" %(__scriptname__.replace(" ","_"),__version__))[ "token" ]
            if results:
                store.set('credentials', results)
        return results
  def searchsubtitles( self, item,imdb_id,year,tvshow,season,episode):
    '''
    if ( self.osdb_token ) :
      searchlist  = []
      lang=[]
      lang.append('heb')

      searchlist.append({'sublanguageid':",".join(lang),
                          'query'        :imdb_id,
                          'year'         :year
                         }) 
      


      search = self.server.SearchSubtitles( self.osdb_token, searchlist )
      log.info('search_result')
      log.info(search)
      log.info(searchlist)
      if search["data"]:
        return search["data"]
      else:
        return 'NOT FOUND'
    '''
    if tvshow:
      
      url='https://www.opensubtitles.org/he/search2?MovieName='+imdb_id+'&action=search&SubLanguageID=heb&SubLanguageID=heb&Season='+season+'&Episode='+episode
 
    else:
      url='https://www.opensubtitles.org/he/search2?MovieName='+imdb_id+'&action=search&SubLanguageID=heb&SubLanguageID=heb'
    req = urllib2.Request(url)
    req.add_header('User-Agent', __USERAGENT__)
    try:
      response = urllib2.urlopen(req).read()
    except:
     return 'BLOCKED'
    if 'itemprop="datePublished"' in response or '<time datetime=' in response:
     return 'FOUND'
    else:
     return  'NOT FOUND'

  def download(self, ID, dest):
     try:
       import zlib, base64
       down_id=[ID,]
       result = self.server.DownloadSubtitles(self.osdb_token, down_id)
       if result["data"]:
         local_file = open(dest, "w" + "b")
         d = zlib.decompressobj(16+zlib.MAX_WBITS)
         data = d.decompress(base64.b64decode(result["data"][0]["data"]))
         local_file.write(data)
         local_file.close()
         log2( __name__,"Download Using XMLRPC")
         return True
       return False
     except:
       return False

def log2(module, msg):
  xbmc.log((u"### [%s] - %s" % (module,msg,)).encode('utf-8'),level=xbmc.LOGDEBUG ) 

def hashFile(file_path, rar):
    if rar:
      return OpensubtitlesHashRar(file_path)
      
    log2( __name__,"Hash Standard file")  
    longlongformat = 'q'  # long long
    bytesize = struct.calcsize(longlongformat)
    f = xbmcvfs.File(file_path)
    
    filesize = f.size()
    hash = filesize
    
    if filesize < 65536 * 2:
        return "SizeError"
    
    buffer = f.read(65536)
    f.seek(max(0,filesize-65536),0)
    buffer += f.read(65536)
    f.close()
    for x in range((65536/bytesize)*2):
        size = x*bytesize
        (l_value,)= struct.unpack(longlongformat, buffer[size:size+bytesize])
        hash += l_value
        hash = hash & 0xFFFFFFFFFFFFFFFF
    
    returnHash = "%016x" % hash
    return filesize,returnHash


def OpensubtitlesHashRar(firsrarfile):
    log2( __name__,"Hash Rar file")
    f = xbmcvfs.File(firsrarfile)
    a=f.read(4)
    if a!='Rar!':
        raise Exception('ERROR: This is not rar file.')
    seek=0
    for i in range(4):
        f.seek(max(0,seek),0)
        a=f.read(100)        
        type,flag,size=struct.unpack( '<BHH', a[2:2+5]) 
        if 0x74==type:
            if 0x30!=struct.unpack( '<B', a[25:25+1])[0]:
                raise Exception('Bad compression method! Work only for "store".')            
            s_partiizebodystart=seek+size
            s_partiizebody,s_unpacksize=struct.unpack( '<II', a[7:7+2*4])
            if (flag & 0x0100):
                s_unpacksize=(struct.unpack( '<I', a[36:36+4])[0] <<32 )+s_unpacksize
                log2( __name__ , 'Hash untested for files biger that 2gb. May work or may generate bad hash.')
            lastrarfile=getlastsplit(firsrarfile,(s_unpacksize-1)/s_partiizebody)
            hash=addfilehash(firsrarfile,s_unpacksize,s_partiizebodystart)
            hash=addfilehash(lastrarfile,hash,(s_unpacksize%s_partiizebody)+s_partiizebodystart-65536)
            f.close()
            return (s_unpacksize,"%016x" % hash )
        seek+=size
    raise Exception('ERROR: Not Body part in rar file.')

def getlastsplit(firsrarfile,x):
    if firsrarfile[-3:]=='001':
        return firsrarfile[:-3]+('%03d' %(x+1))
    if firsrarfile[-11:-6]=='.part':
        return firsrarfile[0:-6]+('%02d' % (x+1))+firsrarfile[-4:]
    if firsrarfile[-10:-5]=='.part':
        return firsrarfile[0:-5]+('%1d' % (x+1))+firsrarfile[-4:]
    return firsrarfile[0:-2]+('%02d' %(x-1) )

def addfilehash(name,hash,seek):
    f = xbmcvfs.File(name)
    f.seek(max(0,seek),0)
    for i in range(8192):
        hash+=struct.unpack('<q', f.read(8))[0]
        hash =hash & 0xffffffffffffffff
    f.close()    
    return hash

def normalizeString(str):
  return unicodedata.normalize(
         'NFKD', unicode(unicode(str, 'utf-8'))
         ).encode('ascii','ignore')
