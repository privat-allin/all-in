# -*- coding: utf-8 -*-
import os, urllib, xbmc, zipfile

def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False

	return True


def metalliqplayers():
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'plugin.video.senyor.imdb.watchlists')):	
	url = "https://bitbucket.org/op-repo/allin-data/raw/a6348d65e4d59f0e9504e1278710e2e93399257f/op_data/metalliq.players/userdata/addon_data/plugin.video.metalliq/players.zip"
	addonsDir = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.metalliq')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass			
			
