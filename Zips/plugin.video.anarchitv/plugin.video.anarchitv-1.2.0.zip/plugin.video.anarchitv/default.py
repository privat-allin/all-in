# -*- coding: utf-8 -*-
"""
Copyright (C) 2015

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

thanks for podgod and Coder Alpha for the code
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>
"""

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon


plugin_handle = int(sys.argv[1])
mysettings = xbmcaddon.Addon(id = 'plugin.video.anarchitv')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
getSetting = xbmcaddon.Addon().getSetting
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
iconpath = xbmc.translatePath(os.path.join(home, 'resources/icons/'))
icon = xbmc.translatePath(os.path.join(home, 'resources/icons/icon.png'))

xml_regex = '<title>(.*?)</title>\s*<link>(.*?)</link>\s*<thumbnail>(.*?)</thumbnail>'
m3u_thumb_regex = 'logo=[\'"](.*?)[\'"]'
m3u_channel_id = 'channel-id=[\'"](.*?)[\'"]'
group_title_regex = 'group-title=[\'"](.*?)[\'"]'
m3u_regex = '#(.+?),(.+)\s*(.+)\s*'
ondemand_regex = '[ON\'](.*?)[\'nd]'
yt = 'http://www.youtube.com'
m3u = 'http://anarchitv.co/TV/IPTV'

					
def read_file(file):
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass
		

def make_request(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason

			
def main():
	addDir('[COLOR white]עידן פלוס[/COLOR]','רדיו חי', 110, '%s/Radio_icon.png'% iconpath, fanart)
	addDir('[COLOR green]99fm - ?איפה תפסנו אותך[/COLOR]', 'eco99fm', 82, '%s/eifo.png'% iconpath, fanart)	
	addDir('[COLOR red]Eco 99fm - ערוצי מוזיקה[/COLOR]', 'eco feel good', 81, '%s/Eco99-FBimage.jpg'% iconpath, fanart)	
	addDir('[COLOR blue]רדיוס[/COLOR]', 'רדיוס', 52, '%s/100.png'% iconpath, fanart)
	addDir('[COLOR orange]גלגל"צ[/COLOR]', 'גלגל"צ', 53, '%s/GLGLTZ_NewLogo_2013.jpg'% iconpath, fanart)
	addDir('[COLOR brown]תאגיד כאן[/COLOR]', 'תאגיד כאן', 57, '%s/365.jpg'% iconpath, fanart)
	#addDir('[COLOR yellow][B]כל הפלייליסטים[/B][/COLOR]', yt, 1, '%s/allchannels.png'% iconpath, fanart)
	addDir('[COLOR yellow]ערוצי מוזיקה - יוטיוב[/COLOR]','ערוצי מוזיקה - יוטיוב', 108, '%s/radiofm.png'% iconpath, fanart)		
	addDir('[COLOR white]רדיו חי[/COLOR]','רדיו חי', 109, '%s/Radio_icon.png'% iconpath, fanart)	
	
def ecomusic():
	addDir('[COLOR red]Eco Feel Good - שירים למצב רוח טוב[/COLOR]', 'eco feel good', 56, '%s/Road-Calm.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco ישראלי - מוזיקה ישראלית עם כל השירים הגדולים[/COLOR]', 'ית עם כל השירי', 72, '%s/channels03-ISRAELI.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco - ישראל מפעם[/COLOR]', 'Eco Special', 54, '%s/nostalgic_main.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Me - המוזיקה שערכתם בעצמכם[/COLOR]', 'Eco Me', 65, '%s/eco_me.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Artisit - כל האמנים השווים[/COLOR]', 'Eco Artist', 63, '%s/eco_artist.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Special - המיוחדים שלנו[/COLOR]', 'Eco Special', 58, '%s/special-amy.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Top Hits - מיטב הלהיטים החדשים הטובים והשווים באמת[/COLOR]', 'Eco Top Hits', 61, '%s/swift01.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco DJ Sets - הסטים הרותחים ביותר[/COLOR]', 'eco_DJ_sets', 78, '%s/dj_set.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Love - שירי האהבה הגדולים מכל הזמנים[/COLOR]', 'eco love', 79, '%s/love.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco My Music - מוזיקה שאמנים אוהבים[/COLOR]', 'my music', 80, '%s/music.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Chill Out - שירים להירגע איתם[/COLOR]', 'Eco Artist', 91, '%s/Chill-trees.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Shhh - מוזיקה שקטה נעימה ורגועה[/COLOR]', 'רדיו', 92, '%s/ecoshhhh.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Holidays - שירי חגים[/COLOR]', 'Eco Holidays', 93, '%s/eco_holiday_03.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Kids - שירים שילדים אוהבים[/COLOR]', 'Eco Kids', 94, '%s/eco_kids_05.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Playlist - החדשים והנכונים[/COLOR]', 'Eco Artist', 95, '%s/eco_playlist_dark.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Family - מוזיקה שכל המשפחה אוהבת[/COLOR]', 'Eco Family', 96, '%s/eco_family_02.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Black Music - מוזיקה שחורה ומעולה בקצב מדהים[/COLOR]', 'Eco Black Music', 97, '%s/eco_black_music_03.jpg'% iconpath, fanart)
	#addDir('[COLOR red]Eco Stuff Pick - מוזיקה שהעורכים שלנו אוהבים במיוחד[/COLOR]', 'Eco Stuff Pick', 98, '%s/eco_staff_pick_new_02.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Winter - מוזיקה מעולה לעונה קרה[/COLOR]', 'Eco Winter', 99, '%s/eco_winter_main_03.jpg'% iconpath, fanart)	
	addDir('[COLOR red]Eco Dance - שירים קצביים שכיף לרקוד איתם[/COLOR]', 'Eco Dance', 100, '%s/DANCE2.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Rock - מוזיקת רוק מיטב הלהיטים מכל הזמנים[/COLOR]', 'Eco Rock', 101, '%s/Rock-guitar.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco Workout - שירים לריצה ואימונים[/COLOR]', 'Eco Workout', 102, '%s/Run-01.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco 60 -70 - שירי שנות השישים והשבעים[/COLOR]', 'Eco 60 -70', 103, '%s/70.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco 80 - הלהיטים הגדולים של שנות השמונים[/COLOR]', 'co 80', 104, '%s/80.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco 90 - הלהיטים הגדולים של שנות התשעים[/COLOR]', 'Eco 90', 105, '%s/90.jpg'% iconpath, fanart)
	addDir('[COLOR red]Eco 2000 - שנות האלפיים[/COLOR]', 'Eco 2000', 106, '%s/eco_2000_02.jpg'% iconpath, fanart)

	
def musicmod():
	addDir('[COLOR green]בדיוק קמתי[/COLOR]', 'eco feel good', 83, '%s/sun.png'% iconpath, fanart)
	addDir('[COLOR green]בדרכים[/COLOR]', 'eco99fm', 84, '%s/Shape.png'% iconpath, fanart)
	addDir('[COLOR green]רוצה לרקוד[/COLOR]', 'Eco Me', 85, '%s/Ellipse.png'% iconpath, fanart)
	addDir('[COLOR green]בעבודה[/COLOR]', 'Eco Artist', 86, '%s/Rounded_Rectangle.png'% iconpath, fanart)
	addDir('[COLOR green]עם החברים[/COLOR]', 'Eco Special', 87, '%s/Ellipseaa.png'% iconpath, fanart)
	addDir('[COLOR green]עושה ספורט[/COLOR]', 'רדיו', 88, '%s/Rectangles.png'% iconpath, fanart)
	addDir('[COLOR green]בקטע רומנטי[/COLOR]', 'eco_DJ_sets', 89, '%s/Shapel.png'% iconpath, fanart)
	addDir('[COLOR green]בבית[/COLOR]', 'eco love', 90, '%s/home.png'% iconpath, fanart)

	
def removeAccents(s):
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))
	
	
def search(): 	
	try:
		keyb = xbmc.Keyboard('', 'חיפוש') 
		keyb.doModal()
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)
	except:
		pass

def rudius(): 	
	try:
		searchText = (u'רדיוס')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	

	
def galatz(): 	
	try:
		searchText = (u'גלגל"צ')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	
	
def ilold(): 	
	try:
		searchText = (u'ישראל מפעם')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	
	
def ecofeelgood(): 	
	try:
		searchText = (u'eco feel good')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass


		
def ecoartist(): 	
	try:
		searchText = (u'eco artist')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

		
	
def ecofm(): 	
	try:
		searchText = (u'תאגיד כאן')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	


def ecospecial(): 	
	try:
		searchText = (u'eco special')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def eco_DJ_sets(): 	
	try:
		searchText = (u'eco DJ sets')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass		

def eco_love(): 	
	try:
		searchText = (u'eco love')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def my_music(): 	
	try:
		searchText = (u'my music')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
		
def ecome(): 	
	try:
		searchText = (u'eco me')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)
	except:
		pass

def ecotophits(): 	
	try:
		searchText = (u'top hits')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
	
def israel(): 	
 	#try:

		searchText = (u'ישראל')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			soup = getSoup()				
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):					
					if 'channel-id' in thumb: 			
			 			channel_id = None
			 			try:
			 				channel_id = re.compile(m3u_channel_id).findall(str(thumb))[0].replace(' ', '%20')			 			 	
			 			except:
			 				pass
			 			#9,10,11,21,24,33,22,99
			 		myList = [9,10,11,21,24,33,22,99,20,26]	
			 		epgText = None
				 	epgDesc = None	
				 	
				 	print channel_id		
			 		if int(channel_id) in myList:
			 			
				 		epgOject = getEpgText(channel_id,soup)				 		
				 		if len(epgOject)> 0:
				 			epgText = epgOject[0]['epgText']	
				 			epgDesc = epgOject[0]['epgDesc']
					m3u_playlist(name, url, thumb, epgText,epgDesc)
		SetViewMode()					
  	#except:
  		#pass

	

def EcoShhh(): 	
	try:
		searchText = (u'Eco Shhh')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
		
def qmusic(): 	
	try:
		searchText = (u'מוזיקה שקטה')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
		
def dancemusic(): 	
	try:
		searchText = (u'מוזיקה לריקודים')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
		
def ilmusic(): 	
	try:
		searchText = (u'eco ישראלי')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
		
def qumusic(): 	
	try:
		searchText = (u'מוזיקה שקטה')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
		
def ahome(): 	
	try:
		searchText = (u'בבית')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
		
def musicmoda(): 	
	try:
		searchText = (u'בדיוק קמתי')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def musicmodb(): 	
	try:
		searchText = (u'בדרכים')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def musicmodc(): 	
	try:
		searchText = (u'רוצה לרקוד')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def musicmodd(): 	
	try:
		searchText = (u'בעבודה')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def musicmode(): 	
	try:
		searchText = (u'עם החברים')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def musicmodf(): 	
	try:
		searchText = (u'עושה ספורט')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def musicmodg(): 	
	try:
		searchText = (u'בקטע רומנטי')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def musicmodh(): 	
	try:
		searchText = (u'בבית')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass		
		
def getup(): 	
	try:
		searchText = (u'בדיוק קמתי')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
		
		
def chillout(): 	
	try:
		searchText = (u'eco chill out')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass
		
def ecoholidays(): 	
	try:
		searchText = (u'eco holidays')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def ecokids(): 	
	try:
		searchText = (u'eco kids')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass	

def ecoplaylist(): 	
	try:
		searchText = (u'eco playlist')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass	

def ecofamily(): 	
	try:
		searchText = (u'eco family')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass	

def ecoblackmusic(): 	
	try:
		searchText = (u'eco black music')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass	

def EcoStuffPick(): 	
	try:
		searchText = (u'eco Stuff Pick')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass	

def ecowinter(): 	
	try:
		searchText = (u'eco winter')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def ecodance(): 	
	try:
		searchText = (u'eco dance')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def ecorock(): 	
	try:
		searchText = (u'eco rock')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def ecoworkout(): 	
	try:
		searchText = (u'eco workout')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def ecosevens(): 	
	try:
		searchText = (u'eco 70s')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def ecoeights(): 	
	try:
		searchText = (u'eco 80s')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def econins(): 	
	try:
		searchText = (u'eco 90s')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def ecotow(): 	
	try:
		searchText = (u'eco 2000')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass

def radiobk(): 	
	try:
		searchText = (u'רדיו -')
		if len(List) > 0:		
			content = make_request(List)
			match = re.compile(m3u_regex).findall(content)
			for thumb, name, url in match:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)	
	except:
		pass		
	
		
def text_online():		
	content = make_request(text)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass

	
def m3u_online():		
	content = make_request(List)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass
			
def m3u_online2():		
	content = make_request(Listb)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass	

def m3u_online3():		
	content = make_request(Listc)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass

def m3u_online4():		
	content = make_request(Listd)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass			

def m3u_playlist(name, url, thumb,epgText = None, epgDesc = None):	
	ch = thumb
	print thumb
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			addDir(name, url, '', thumb, thumb)			
		else:	
			addDir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			addLink(name, url, 1, thumb, thumb,epgText,epgDesc)			
		else:				
			addLink(name, url, 1, icon, fanart,None)

def getSoup():
	r = requests.get('https://raw.githubusercontent.com/anarchitv/rep/master/WALL.xml')
	r.encoding = 'utf-8'
	soup = BeautifulSoup(r.text,'html.parser')
	return soup

def getEpgText(Epgid,soup):
	
	title = ''
	now = datetime.datetime.now()	
	myyear = now.year
	mymonth = now.month
	myday = now.day
	if mymonth<10:
		mymonth = '0' + str(mymonth)
	if myday<10:
		myday = '0' + str(myday)
		

	programme = soup.findAll('programme', {'channel': str(Epgid),'start': lambda L: L and L.startswith(str(myyear) + str(mymonth) + str(myday))})
	 
	epgText = ''
	epgDesc = ''
	resultsList = []
	for p in programme:
		
	    
		start =  int(p.get('start').replace('+0300',''))
		stop =  int(p.get('stop').replace('+0300',''))
		start = start / 100 % 10000
		stop =  stop / 100 % 10000
		TimeNow =  ((int(now.hour) * 100) + int(now.minute)) 
	   
		if start <= TimeNow <= stop:
			
			epgText = '( ' + str(stop) + ' - '  + str(start) + ' ) ' + str(p.find("title")).replace('<title lang="he">', '').replace('</title>', '')
			if p.find("desc")<>None:
				epgDesc =  str(p.find("desc")).replace('<desc lang="he">', '').replace('</desc>', '')
			resultsList.append({'epgText':epgText,'epgDesc':epgDesc})
			break
	return resultsList
    

def getHour(h):	 
    if len(h) == 1:
    	h = '000' + h
    elif len(h) == 2:
    	h = '00' + h	
    elif len(h) == 3:
    	h = '0' + h
    h = h[:2] + ':' + h[2:]
    return h

def play_video(url):
	media_url = url
	item = xbmcgui.ListItem(name, path = media_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	return

def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param

def SetViewMode():
	xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
	xbmc.executebuiltin("Container.SetViewMode(504)")

List = 'http://tiny.cc/b2k_music_global'	
#List = 'https://goo.gl/iZyohj'
Listb = 'http://pastebin.com/raw/RrsncSTU'
Listc = 'http://pastebin.com/raw/6QsDzJSA'
Listd = 'https://pastebin.com/raw/QiMLEstd'
def addDir(name, url, mode, iconimage, fanart):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok		

def addDir2(name, url, mode, iconimage, fanart):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = False)
	return ok	
	
def addLink(name, url, mode, iconimage, fanart, epgText = None,EpgDesc = None):
	try:
		if epgText != None and epgText != '' :
			name =  epgText + '[COLOR yellow]' + name + '[/COLOR]' 

	except:
		pass
	
	
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name, "plot": EpgDesc  } )
	liz.setProperty('', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz) 	
		
params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass  

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)		

if mode == None or url == None or len(url) < 1:
	main()

elif mode == 1:
	play_video(url)

elif mode == 2:
	m3u_online()
	
elif mode == 3:
	text_online()
	
elif mode == 4:
	main2()
	
elif mode == 51:
	HD()
		
elif mode == 52:
	rudius()
	
elif mode == 53:
	galatz()
	
elif mode == 54:
	ilold()
	
elif mode == 55:
	entertainment()
	
elif mode == 56:
	ecofeelgood()
	
elif mode == 57:
	ecofm()
	
elif mode == 58:
	ecospecial()
	
elif mode == 65:
	ecome()
	
elif mode == 60:
	twentyfour7()
	
elif mode == 61:
	ecotophits()
	
elif mode == 62:
	israel()

elif mode == 69:
	idan()
	
elif mode == 70:
	qmusic()
	
elif mode == 71:
	dancemusic()
	
elif mode == 72:
	ilmusic()
	
elif mode == 73:
	qumusic()
	
elif mode == 74:
	ahome()
	
elif mode == 75:
	getup()
	
elif mode == 76:
	Brazilian()
	
elif mode == 77:
	Arabic()

elif mode == 63:
	ecoartist()
	
elif mode == 64:
	international()

elif mode == 78:
	eco_DJ_sets()

elif mode == 79:
	eco_love()

elif mode == 80:
	my_music()
	
elif mode == 81:
	ecomusic()

elif mode == 82:
	musicmod()

elif mode == 83:
	musicmoda()

elif mode == 84:
	musicmodb()

elif mode == 85:
	musicmodc()

elif mode == 86:
	musicmodd()

elif mode == 87:
	musicmode()

elif mode == 88:
	musicmodf()

elif mode == 89:
	musicmodg()

elif mode == 90:
	musicmodh()	
	
elif mode == 91:
	chillout()

elif mode == 92:
	EcoShhh()	

elif mode == 93:
	ecoholidays()
	
elif mode == 94:
	ecokids()
	
elif mode == 95:
	ecoplaylist()
	
elif mode == 96:
	ecofamily()

elif mode == 97:
	ecoblackmusic()

elif mode == 98:
	EcoStuffPick()

elif mode == 99:
	ecowinter()

elif mode == 100:
	ecodance()

elif mode == 101:
	ecorock()

elif mode == 102:
	ecoworkout()

elif mode == 103:
	ecosevens()

elif mode == 104:
	ecoeights()

elif mode == 105:
	econins()

elif mode == 106:
	ecotow()

elif mode == 107:
	m3u_online2()

elif mode == 108:
	m3u_online3()

elif mode == 109:
	radiobk()

elif mode == 110:
	m3u_online4()	
	

xbmcplugin.endOfDirectory(plugin_handle)